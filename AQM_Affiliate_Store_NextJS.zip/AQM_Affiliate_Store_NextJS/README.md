# AQM Affiliate Store — Next.js

تم تحويل واجهة المشروع من Vite إلى **Next.js App Router** مع الإبقاء على واجهة React الحالية وربط Supabase من المتصفح باستخدام المفتاح العام فقط.

## المتطلبات
- Node.js 20.9 أو أحدث.
- مشروع Supabase.

## التشغيل محليًا
1. فك ضغط المشروع وافتح مجلده.
2. انسخ `.env.example` إلى `.env.local`.
3. ضع بيانات مشروع Supabase في `.env.local`:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
   ```
4. من مجلد المشروع شغّل:
   ```bash
   npm install
   npm run dev
   ```
5. افتح `http://localhost:3000`.

## إعداد Supabase
1. افتح SQL Editor في مشروع Supabase.
2. نفّذ محتوى `supabase/schema.sql`.
3. تأكد من تفعيل RLS والسياسات الموجودة في المخطط.
4. أنشئ حساب الأدمن بالطريقة الموضحة في ملف المخطط/التعليمات الأصلية، ولا تضع أي `service_role` أو Secret Key في متغيرات `NEXT_PUBLIC_`.

## بنية Next.js
- `app/layout.jsx`: تخطيط التطبيق والبيانات الوصفية واتجاه RTL.
- `app/page.jsx`: واجهة التطبيق الحالية (Client Component لأنها تستخدم الحالة والتفاعلات ومصادقة Supabase).
- `app/globals.css`: تنسيقات الموقع.
- `supabase/schema.sql`: مخطط قاعدة البيانات وسياسات التخزين والصلاحيات.

## ملاحظات مهمة
- متغيرات `NEXT_PUBLIC_` تكون متاحة في المتصفح؛ استخدم فقط Supabase publishable/anon key مع RLS مضبوط.
- لا تستخدم `service_role` أو Secret Key في الواجهة أو في أي متغير يبدأ بـ `NEXT_PUBLIC_`.
- هذا تحويل لبنية المشروع إلى Next.js وليس مراجعة أمنية نهائية. قبل الاستخدام التجاري اختبر تدفقات التسجيل والطلبات والعمولات والسحب ورفع الصور بحساب أدمن وحسابين للمسوقين.
- إذا غيّرت قيم البيئة بعد البناء، أعد تشغيل خادم التطوير أو أعد بناء التطبيق في بيئة الإنتاج.
