'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { ShoppingBag, LogOut, LayoutDashboard, Package, ClipboardList, Wallet, Users, Plus, Check, X, RefreshCw } from 'lucide-react';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const supabase = url && anon ? createClient(url, anon) : null;
const egp = n => `${Number(n || 0).toLocaleString('ar-EG')} ج.م`;

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [screen, setScreen] = useState('home');
  const [products, setProducts] = useState([]);
  const [banners, setBanners] = useState([]);
  const [bannerIndex, setBannerIndex] = useState(0);
  const [bannerFile, setBannerFile] = useState(null);
  const [productImage, setProductImage] = useState(null);
  const [orders, setOrders] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [affiliates, setAffiliates] = useState([]);
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [productForm, setProductForm] = useState({name:'', description:'', price:'', commission:'', stock:'0'});
  const [orderForm, setOrderForm] = useState({productId:'', customerName:'', customerPhone:'', customerAddress:''});
  const [withdrawForm, setWithdrawForm] = useState({amount:'', method:'', details:''});

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({data}) => setSession(data.session));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session || !supabase) { setProfile(null); return; }
    loadProfile();
  }, [session]);

  useEffect(() => {
    if (profile) {
      setScreen(profile.role === 'admin' ? 'dashboard' : 'home');
      loadData();
    }
  }, [profile?.id, profile?.role]);

  async function loadProfile() {
    const {data, error} = await supabase.from('profiles').select('*').eq('id', session.user.id).single();
    if (error) { setNotice('تعذر تحميل الملف الشخصي. تأكد من تنفيذ ملف قاعدة البيانات.'); return; }
    setProfile(data);
  }
  async function loadData() {
    setBusy(true); setNotice('');
    const p = await supabase.from('products').select('*').order('created_at', {ascending:false});
    if (!p.error) setProducts(p.data || []);
    const b = await supabase.from('banners').select('*').order('sort_order', {ascending:true});
    if (!b.error) setBanners(b.data || []);
    const o = await supabase.from('orders').select('*, products(name), profiles:profiles!orders_affiliate_id_fkey(full_name,email)').order('created_at',{ascending:false});
    if (!o.error) setOrders(o.data || []);
    const w = await supabase.from('withdrawals').select('*, profiles:profiles!withdrawals_affiliate_id_fkey(full_name,email)').order('created_at',{ascending:false});
    if (!w.error) setWithdrawals(w.data || []);
    if (profile?.role === 'admin') {
      const a = await supabase.from('profiles').select('id,full_name,email,role,created_at').eq('role','affiliate').order('created_at',{ascending:false});
      if (!a.error) setAffiliates(a.data || []);
    }
    setBusy(false);
  }

  useEffect(() => {
    if (!session || !supabase) return;
    const channel = supabase.channel('aqm-live-catalog')
      .on('postgres_changes', {event:'*', schema:'public', table:'products'}, () => loadData())
      .on('postgres_changes', {event:'*', schema:'public', table:'banners'}, () => loadData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [session?.user?.id]);

  async function uploadImage(file, folder) {
    if (!file) return null;
    if (!['image/jpeg','image/png','image/webp'].includes(file.type) || file.size > 5*1024*1024) {
      setNotice('اختاري صورة JPG أو PNG أو WebP بحجم لا يتجاوز 5 ميجابايت.'); return null;
    }
    const ext = file.name.split('.').pop().toLowerCase();
    const path = `${folder}/${crypto.randomUUID()}.${ext}`;
    const {error} = await supabase.storage.from('aqm-media').upload(path, file, {upsert:false, contentType:file.type});
    if (error) { setNotice('فشل رفع الصورة. تأكدي من إعداد مخزن الصور والصلاحيات.'); return null; }
    return supabase.storage.from('aqm-media').getPublicUrl(path).data.publicUrl;
  }

  async function addBanner(e) {
    e.preventDefault(); if (!bannerFile) { setNotice('اختاري صورة البانر أولًا.'); return; }
    setBusy(true); const image_url = await uploadImage(bannerFile, 'banners');
    if (image_url) { const {error} = await supabase.from('banners').insert({image_url, sort_order:banners.length, active:true}); setNotice(error ? 'تعذر حفظ البانر.' : 'تمت إضافة البانر.'); if (!error) {setBannerFile(null); e.target.reset(); loadData();} }
    setBusy(false);
  }
  async function deleteBanner(b) {
    const {error} = await supabase.from('banners').delete().eq('id', b.id); setNotice(error ? 'تعذر حذف البانر.' : 'تم حذف البانر.'); loadData();
  }
  async function toggleBanner(b) {
    const {error} = await supabase.from('banners').update({active:!b.active}).eq('id', b.id); setNotice(error ? 'تعذر تحديث البانر.' : 'تم تحديث البانر.'); loadData();
  }
  async function authSubmit(e) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setNotice('');
    if (mode === 'signup') {
      const {error} = await supabase.auth.signUp({email, password, options:{data:{full_name:fullName}}});
      setNotice(error ? error.message : 'تم إنشاء الحساب. إذا كان تأكيد البريد مفعّلًا، افتح رسالة التأكيد ثم سجّل الدخول.');
    } else {
      const {error} = await supabase.auth.signInWithPassword({email,password});
      if (error) setNotice('تعذر تسجيل الدخول: تحقق من البريد وكلمة المرور.');
    }
    setBusy(false);
  }
  async function signOut() { await supabase.auth.signOut(); setScreen('home'); setProfile(null); }
  async function addProduct(e) {
    e.preventDefault();
    const price=Number(productForm.price), commission=Number(productForm.commission), stock=Number(productForm.stock);
    if (!productForm.name.trim() || price<=0 || commission<0 || stock<0) {setNotice('أدخل بيانات منتج صحيحة.');return;}
    let image_url = null;
    if (productImage) { image_url = await uploadImage(productImage, 'products'); if (!image_url) return; }
    const {error}=await supabase.from('products').insert({name:productForm.name.trim(),description:productForm.description,price,commission,stock,image_url,active:true});
    if(error) setNotice('لم تتم إضافة المنتج. تأكد من صلاحية الأدمن.');
    else {setProductForm({name:'',description:'',price:'',commission:'',stock:'0'});setProductImage(null);setNotice('تمت إضافة المنتج، وسيظهر تلقائيًا لكل المسوقين.');loadData();}
  }
  async function toggleProduct(p) {
    const {error}=await supabase.from('products').update({active:!p.active}).eq('id',p.id);
    setNotice(error?'تعذر تعديل المنتج.':'تم تحديث حالة المنتج.');loadData();
  }
  async function createOrder(e) {
    e.preventDefault();
    const p=products.find(x=>x.id===orderForm.productId);
    if(!p || !orderForm.customerName.trim() || !orderForm.customerPhone.trim() || !orderForm.customerAddress.trim()){setNotice('أكمل بيانات العميل واختر المنتج.');return;}
    const {error}=await supabase.from('orders').insert({
      affiliate_id:session.user.id, product_id:p.id, product_name:p.name,
      product_price:p.price, commission_amount:p.commission,
      customer_name:orderForm.customerName.trim(), customer_phone:orderForm.customerPhone.trim(),
      customer_address:orderForm.customerAddress.trim(), status:'pending', commission_status:'pending'
    });
    if(error) setNotice('تعذر إرسال الطلب. حاول مرة أخرى.');
    else {setOrderForm({productId:'',customerName:'',customerPhone:'',customerAddress:''});setNotice('تم إرسال الطلب إلى الأدمن للمراجعة.');setScreen('orders');loadData();}
  }
  async function decideOrder(order, status) {
    const patch = {status, commission_status: status==='approved' ? 'approved' : 'rejected', reviewed_at:new Date().toISOString(), reviewed_by:session.user.id};
    const {error}=await supabase.from('orders').update(patch).eq('id',order.id);
    setNotice(error?'تعذر تحديث الطلب.':'تم تحديث حالة الطلب والعمولة.');loadData();
  }
  const approvedEarnings = useMemo(()=>orders.filter(o=>o.affiliate_id===session?.user?.id && o.commission_status==='approved').reduce((s,o)=>s+Number(o.commission_amount),0),[orders,session]);
  const pendingEarnings = useMemo(()=>orders.filter(o=>o.affiliate_id===session?.user?.id && o.commission_status==='pending').reduce((s,o)=>s+Number(o.commission_amount),0),[orders,session]);
  const pendingWithdrawals = useMemo(()=>withdrawals.filter(w=>w.affiliate_id===session?.user?.id && ['pending','approved'].includes(w.status)).reduce((s,w)=>s+Number(w.amount),0),[withdrawals,session]);
  const available = Math.max(0, approvedEarnings-pendingWithdrawals);
  async function requestWithdrawal(e) {
    e.preventDefault(); const amount=Number(withdrawForm.amount);
    if(amount<=0 || amount>available || !withdrawForm.method.trim() || !withdrawForm.details.trim()){setNotice('تحقق من المبلغ وطريقة السحب والبيانات.');return;}
    const {error}=await supabase.from('withdrawals').insert({affiliate_id:session.user.id,amount,method:withdrawForm.method,details:withdrawForm.details,status:'pending'});
    setNotice(error?'تعذر إرسال طلب السحب.':'تم إرسال طلب السحب للمراجعة.'); if(!error){setWithdrawForm({amount:'',method:'',details:''});loadData();}
  }
  async function decideWithdrawal(w,status) {
    const {error}=await supabase.from('withdrawals').update({status,reviewed_at:new Date().toISOString(),reviewed_by:session.user.id}).eq('id',w.id);
    setNotice(error?'تعذر تحديث طلب السحب.':'تم تحديث طلب السحب.');loadData();
  }

  if (!supabase) return <main className="setup"><h1>AQM | متجر الأفلييت</h1><p>قبل التشغيل، أنشئ مشروع Supabase وانسخ بياناته إلى ملف <code>.env</code>.</p><p>شغّل ملف <code>supabase/schema.sql</code> في SQL Editor أولًا.</p><p>راجع README لمعرفة خطوات الإعداد وتحويل حسابك إلى أدمن.</p></main>;
  if (!session) return <main className="auth">
    <div className="brand"><ShoppingBag size={30}/><h1>AQM</h1><p>منصة التسويق بالعمولة</p></div>
    <form onSubmit={authSubmit} className="panel">
      <h2>{mode==='login'?'تسجيل الدخول':'إنشاء حساب مسوق'}</h2>
      {mode==='signup' && <label>الاسم الكامل<input required value={fullName} onChange={e=>setFullName(e.target.value)} /></label>}
      <label>البريد الإلكتروني<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} /></label>
      <label>كلمة المرور<input type="password" required minLength="8" value={password} onChange={e=>setPassword(e.target.value)} /></label>
      <button className="primary" disabled={busy}>{busy?'جارٍ التنفيذ...':mode==='login'?'دخول':'إنشاء حساب مسوق'}</button>
      <button type="button" className="link" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'ليس لديك حساب؟ سجّل كمسوق':'لديك حساب؟ سجّل الدخول'}</button>
      {notice && <p className="notice">{notice}</p>}
    </form>
  </main>;

  if (!profile) return <main className="setup"><p>جارٍ تحميل الحساب...</p>{notice}</main>;
  const admin=profile.role==='admin';
  const nav=admin ? [['dashboard','لوحة التحكم',LayoutDashboard],['products','المنتجات',Package],['banners','البانرات',Package],['orders','الطلبات',ClipboardList],['affiliates','المسوقون',Users],['withdrawals','طلبات السحب',Wallet]] :
    [['home','المنتجات',ShoppingBag],['orders','طلباتي',ClipboardList],['earnings','الأرباح',LayoutDashboard],['withdrawals','السحب',Wallet]];
  return <div className="app">
    <header className="topbar"><div><b>AQM</b><span>{admin?'لوحة الأدمن':'لوحة المسوق'}</span></div><div className="user"><span>{profile.full_name || session.user.email}</span><button title="تسجيل الخروج" onClick={signOut}><LogOut size={18}/></button></div></header>
    <div className="layout"><aside className="sidebar">{nav.map(([id,label,Icon])=><button key={id} className={screen===id?'selected':''} onClick={()=>setScreen(id)}><Icon size={18}/>{label}</button>)}<button onClick={loadData}><RefreshCw size={18}/>تحديث البيانات</button></aside>
    <main className="main">
      {notice && <div className="notice" role="status">{notice}<button onClick={()=>setNotice('')}>×</button></div>}
      {busy && <p className="muted">جارٍ تحديث البيانات...</p>}
      {screen==='dashboard' && admin && <><h1>نظرة عامة</h1><div className="cards"><Stat title="إجمالي الطلبات" value={orders.length}/><Stat title="طلبات قيد المراجعة" value={orders.filter(o=>o.status==='pending').length}/><Stat title="المسوقون" value={affiliates.length}/><Stat title="طلبات السحب المعلقة" value={withdrawals.filter(w=>w.status==='pending').length}/></div><h2>أحدث الطلبات</h2><OrderTable orders={orders.slice(0,8)} admin onDecision={decideOrder}/></>}
      {screen==='products' && admin && <><h1>إدارة المنتجات والعمولات</h1><form className="panel formgrid" onSubmit={addProduct}><label>اسم المنتج<input required value={productForm.name} onChange={e=>setProductForm({...productForm,name:e.target.value})}/></label><label>سعر البيع بالجنيه<input type="number" min="0.01" step="0.01" required value={productForm.price} onChange={e=>setProductForm({...productForm,price:e.target.value})}/></label><label>عمولة ثابتة بالجنيه<input type="number" min="0" step="0.01" required value={productForm.commission} onChange={e=>setProductForm({...productForm,commission:e.target.value})}/></label><label>المخزون<input type="number" min="0" required value={productForm.stock} onChange={e=>setProductForm({...productForm,stock:e.target.value})}/></label><label className="wide">الوصف<textarea value={productForm.description} onChange={e=>setProductForm({...productForm,description:e.target.value})}/></label><label className="wide">صورة المنتج من الجهاز<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setProductImage(e.target.files?.[0]||null)}/></label>{productImage&&<img className="upload-preview" src={URL.createObjectURL(productImage)} alt="معاينة صورة المنتج"/>}<button className="primary">إضافة المنتج</button></form><div className="productgrid">{products.map(p=><article className="panel" key={p.id}>{p.image_url&&<img className="product-photo" src={p.image_url} alt={p.name}/>}<h3>{p.name}</h3><p>{p.description}</p><b>{egp(p.price)}</b><p>عمولة المسوق: <strong>{egp(p.commission)}</strong></p><p>المخزون: {p.stock}</p><button className={p.active?'secondary':'primary'} onClick={()=>toggleProduct(p)}>{p.active?'إيقاف المنتج':'تفعيل المنتج'}</button></article>)}</div></>}
      {screen==='banners' && admin && <><h1>إدارة البانرات</h1><form className="panel stack narrow" onSubmit={addBanner}><label>اختاري صورة من الموبايل أو الكمبيوتر<input type="file" accept="image/png,image/jpeg,image/webp" required onChange={e=>setBannerFile(e.target.files?.[0]||null)}/></label>{bannerFile&&<img className="upload-preview" src={URL.createObjectURL(bannerFile)} alt="معاينة البانر"/>}<button className="primary" disabled={busy}>رفع ونشر البانر</button></form><div className="banner-admin-grid">{banners.map(b=><article className="panel" key={b.id}><img className="banner-admin-photo" src={b.image_url} alt="بانر"/><div className="actions"><button className="secondary" onClick={()=>toggleBanner(b)}>{b.active?'إيقاف':'تفعيل'}</button><button className="reject" onClick={()=>deleteBanner(b)}>حذف</button></div></article>)}</div></>}
      {screen==='home' && !admin && <>{banners.filter(x=>x.active).length>0&&<section className="banner-slider"><img src={banners.filter(x=>x.active)[bannerIndex % banners.filter(x=>x.active).length].image_url} alt="إعلان" onTouchStart={e=>{window.__bannerTouchX=e.touches[0].clientX}} onTouchEnd={e=>{const dx=e.changedTouches[0].clientX-window.__bannerTouchX;if(Math.abs(dx)>40)setBannerIndex(i=>(i+(dx<0?1:-1)+banners.filter(x=>x.active).length)%banners.filter(x=>x.active).length)}}/><div className="banner-controls"><button onClick={()=>setBannerIndex(i=>(i-1+banners.filter(x=>x.active).length)%banners.filter(x=>x.active).length)}>‹</button><span>{banners.filter(x=>x.active).map((_,i)=><button className={i===bannerIndex?'dot active-dot':'dot'} key={i} onClick={()=>setBannerIndex(i)}/>)}</span><button onClick={()=>setBannerIndex(i=>(i+1)%banners.filter(x=>x.active).length)}>›</button></div></section>}<h1>المنتجات المتاحة للتسويق</h1><p className="muted">اختر منتجًا وسجّل بيانات العميل. لا توجد روابط تسويقية.</p><div className="productgrid">{products.filter(p=>p.active).map(p=><article className="panel" key={p.id}>{p.image_url?<img className="product-photo" src={p.image_url} alt={p.name}/>:<div className="emoji">📦</div>}<h3>{p.name}</h3><p>{p.description}</p><p>سعر المنتج: <b>{egp(p.price)}</b></p><p>عمولتك عند اعتماد الطلب: <strong>{egp(p.commission)}</strong></p><form onSubmit={createOrder} className="stack"><input type="hidden" value={orderForm.productId} readOnly/><label>المنتج<select required value={orderForm.productId===p.id?String(p.id):''} onChange={()=>setOrderForm({...orderForm,productId:p.id})}><option value="">اختر هذا المنتج</option><option value={p.id}>{p.name}</option></select></label><label>اسم العميل<input required value={orderForm.productId===p.id?orderForm.customerName:''} onChange={e=>setOrderForm({...orderForm,productId:p.id,customerName:e.target.value})}/></label><label>رقم الهاتف<input required value={orderForm.productId===p.id?orderForm.customerPhone:''} onChange={e=>setOrderForm({...orderForm,productId:p.id,customerPhone:e.target.value})}/></label><label>العنوان بالتفصيل<input required value={orderForm.productId===p.id?orderForm.customerAddress:''} onChange={e=>setOrderForm({...orderForm,productId:p.id,customerAddress:e.target.value})}/></label><button className="primary">إرسال طلب العميل</button></form></article>)}</div></>}
      {screen==='orders' && <><h1>{admin?'كل طلبات العملاء':'طلباتي'}</h1><OrderTable orders={admin?orders:orders.filter(o=>o.affiliate_id===session.user.id)} admin={admin} onDecision={decideOrder}/></>}
      {screen==='affiliates' && admin && <><h1>المسوقون المسجلون</h1><div className="panel tablewrap"><table><thead><tr><th>الاسم</th><th>البريد</th><th>تاريخ التسجيل</th></tr></thead><tbody>{affiliates.map(a=><tr key={a.id}><td>{a.full_name||'—'}</td><td>{a.email}</td><td>{new Date(a.created_at).toLocaleDateString('ar-EG')}</td></tr>)}</tbody></table></div></>}
      {screen==='earnings' && !admin && <><h1>ملخص الأرباح</h1><div className="cards"><Stat title="العمولات المعتمدة" value={egp(approvedEarnings)}/><Stat title="العمولات المعلقة" value={egp(pendingEarnings)}/><Stat title="الرصيد المتاح للسحب" value={egp(available)}/></div><h2>سجل العمولات</h2><OrderTable orders={orders.filter(o=>o.affiliate_id===session.user.id)} admin={false}/></>}
      {screen==='withdrawals' && <><h1>{admin?'طلبات سحب الأرباح':'طلب سحب الأرباح'}</h1>{!admin && <><div className="cards"><Stat title="الرصيد المتاح للسحب" value={egp(available)}/></div><form className="panel stack narrow" onSubmit={requestWithdrawal}><label>المبلغ المطلوب<input type="number" min="1" step="0.01" max={available} required value={withdrawForm.amount} onChange={e=>setWithdrawForm({...withdrawForm,amount:e.target.value})}/></label><label>طريقة السحب<input required placeholder="محفظة إلكترونية / تحويل بنكي" value={withdrawForm.method} onChange={e=>setWithdrawForm({...withdrawForm,method:e.target.value})}/></label><label>بيانات الاستلام<input required placeholder="رقم المحفظة أو بيانات الحساب" value={withdrawForm.details} onChange={e=>setWithdrawForm({...withdrawForm,details:e.target.value})}/></label><button className="primary">إرسال طلب السحب</button></form></> }<div className="panel tablewrap"><table><thead><tr><th>المسوق</th><th>المبلغ</th><th>الطريقة</th><th>الحالة</th>{admin&&<th>إجراء</th>}</tr></thead><tbody>{withdrawals.filter(w=>admin||w.affiliate_id===session.user.id).map(w=><tr key={w.id}><td>{w.profiles?.full_name||'حسابي'}</td><td>{egp(w.amount)}</td><td>{w.method}</td><td><Status value={w.status}/></td>{admin&&<td className="actions">{w.status==='pending'&&<><button className="approve" onClick={()=>decideWithdrawal(w,'paid')}><Check size={16}/> تم الدفع</button><button className="reject" onClick={()=>decideWithdrawal(w,'rejected')}><X size={16}/> رفض</button></>}</td>}</tr>)}</tbody></table></div></>}
    </main></div>
    <footer className="footer">AQM · نسخة أولية متصلة بقاعدة بيانات Supabase. لا تنفّذ تحويلات مالية تلقائيًا؛ تأكيد السحب يتم يدويًا من الأدمن.</footer>
  </div>;
}

function Stat({title,value}) { return <div className="panel stat"><span>{title}</span><strong>{value}</strong></div>; }
function Status({value}) { const labels={pending:'قيد المراجعة',approved:'مقبول',rejected:'مرفوض',paid:'تم الدفع'}; return <span className={'badge '+value}>{labels[value]||value}</span>; }
function OrderTable({orders,admin,onDecision}) {
 return <div className="panel tablewrap"><table><thead><tr><th>رقم الطلب</th>{admin&&<th>المسوق</th>}<th>المنتج</th><th>العميل</th><th>الهاتف</th><th>السعر</th><th>العمولة</th><th>حالة الطلب</th><th>العمولة</th>{admin&&<th>إجراء</th>}</tr></thead><tbody>{orders.map(o=><tr key={o.id}><td>{String(o.id).slice(0,8)}</td>{admin&&<td>{o.profiles?.full_name||o.profiles?.email||'—'}</td>}<td>{o.product_name||o.products?.name||'منتج'}</td><td>{o.customer_name}</td><td>{o.customer_phone}</td><td>{egp(o.product_price)}</td><td>{egp(o.commission_amount)}</td><td><Status value={o.status}/></td><td><Status value={o.commission_status}/></td>{admin&&<td className="actions">{o.status==='pending'&&<><button className="approve" onClick={()=>onDecision(o,'approved')}><Check size={16}/> قبول</button><button className="reject" onClick={()=>onDecision(o,'rejected')}><X size={16}/> رفض</button></>}</td>}</tr>)}</tbody></table>{!orders.length&&<p className="muted empty">لا توجد بيانات حتى الآن.</p>}</div>;
}