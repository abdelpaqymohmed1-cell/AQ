import './globals.css';

export const metadata = {
  title: 'AQM | التسويق بالعمولة',
  description: 'متجر AQM للتسويق بالعمولة وإدارة المنتجات والطلبات والعمولات.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
