-- AQM Affiliate Store: run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role text not null default 'affiliate' check (role in ('admin','affiliate')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, full_name, email, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.email, 'affiliate')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  price numeric(12,2) not null check(price > 0),
  commission numeric(12,2) not null default 0 check(commission >= 0),
  stock integer not null default 0 check(stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  affiliate_id uuid not null references public.profiles(id),
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  product_price numeric(12,2) not null check(product_price > 0),
  commission_amount numeric(12,2) not null default 0 check(commission_amount >= 0),
  customer_name text not null,
  customer_phone text not null,
  customer_address text not null,
  status text not null default 'pending' check(status in ('pending','approved','rejected')),
  commission_status text not null default 'pending' check(commission_status in ('pending','approved','rejected')),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  affiliate_id uuid not null references public.profiles(id),
  amount numeric(12,2) not null check(amount > 0),
  method text not null,
  details text not null,
  status text not null default 'pending' check(status in ('pending','paid','rejected')),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);


-- Always snapshot the authoritative price and fixed commission from the database.
-- This prevents a browser client from submitting a fake commission or price.
create or replace function public.prepare_affiliate_order()
returns trigger language plpgsql security definer set search_path = public
as $$
declare p public.products%rowtype;
begin
  if new.affiliate_id <> auth.uid() and not public.is_admin() then
    raise exception 'You can only create orders for your own affiliate account';
  end if;
  select * into p from public.products where id = new.product_id and active = true;
  if not found then raise exception 'Product is not available'; end if;
  new.product_name := p.name;
  new.product_price := p.price;
  new.commission_amount := p.commission;
  new.status := 'pending';
  new.commission_status := 'pending';
  new.reviewed_at := null;
  new.reviewed_by := null;
  return new;
end;
$$;
drop trigger if exists prepare_affiliate_order_before_insert on public.orders;
create trigger prepare_affiliate_order_before_insert
before insert on public.orders
for each row execute procedure public.prepare_affiliate_order();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.withdrawals enable row level security;

drop policy if exists "profiles read own or admin" on public.profiles;
create policy "profiles read own or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
-- Profile roles are intentionally not user-editable from the browser.
-- Admin role changes must be made by a trusted project owner in SQL.

drop policy if exists "active products visible" on public.products;
create policy "active products visible" on public.products for select to authenticated
using (active = true or public.is_admin());
drop policy if exists "admin inserts products" on public.products;
create policy "admin inserts products" on public.products for insert to authenticated with check (public.is_admin());
drop policy if exists "admin updates products" on public.products;
create policy "admin updates products" on public.products for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin deletes products" on public.products;
create policy "admin deletes products" on public.products for delete to authenticated using (public.is_admin());

drop policy if exists "affiliate creates own order" on public.orders;
create policy "affiliate creates own order" on public.orders for insert to authenticated
with check (affiliate_id = auth.uid() and status = 'pending' and commission_status = 'pending' and reviewed_by is null);
drop policy if exists "affiliate reads own orders admin reads all" on public.orders;
create policy "affiliate reads own orders admin reads all" on public.orders for select to authenticated
using (affiliate_id = auth.uid() or public.is_admin());
drop policy if exists "admin reviews orders" on public.orders;
create policy "admin reviews orders" on public.orders for update to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "affiliate creates own withdrawal" on public.withdrawals;
create policy "affiliate creates own withdrawal" on public.withdrawals for insert to authenticated
with check (affiliate_id = auth.uid() and status = 'pending' and reviewed_by is null);
drop policy if exists "affiliate reads own withdrawals admin reads all" on public.withdrawals;
create policy "affiliate reads own withdrawals admin reads all" on public.withdrawals for select to authenticated
using (affiliate_id = auth.uid() or public.is_admin());
drop policy if exists "admin reviews withdrawals" on public.withdrawals;
create policy "admin reviews withdrawals" on public.withdrawals for update to authenticated
using (public.is_admin()) with check (public.is_admin());

-- IMPORTANT: After signing up with your own email, promote that account to admin:
-- update public.profiles set role = 'admin' where email = 'YOUR_EMAIL_HERE';
-- Do not expose the Supabase service_role key in the browser.

-- Media and banner carousel additions (safe to run on an existing project).
alter table public.products add column if not exists image_url text;
create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.banners enable row level security;
drop policy if exists "active banners visible" on public.banners;
create policy "active banners visible" on public.banners for select to authenticated
using (active = true or public.is_admin());
drop policy if exists "admin manages banners" on public.banners;
create policy "admin manages banners" on public.banners for all to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Public read access is limited to files in this bucket; only admins can upload/delete.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('aqm-media', 'aqm-media', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp'];
drop policy if exists "AQM media public read" on storage.objects;
create policy "AQM media public read" on storage.objects for select
using (bucket_id = 'aqm-media');
drop policy if exists "AQM media admin upload" on storage.objects;
create policy "AQM media admin upload" on storage.objects for insert to authenticated
with check (bucket_id = 'aqm-media' and public.is_admin());
drop policy if exists "AQM media admin update" on storage.objects;
create policy "AQM media admin update" on storage.objects for update to authenticated
using (bucket_id = 'aqm-media' and public.is_admin())
with check (bucket_id = 'aqm-media' and public.is_admin());
drop policy if exists "AQM media admin delete" on storage.objects;
create policy "AQM media admin delete" on storage.objects for delete to authenticated
using (bucket_id = 'aqm-media' and public.is_admin());

-- Enable realtime updates so new products/banners appear without re-login or manual refresh.
do $$ begin
  alter publication supabase_realtime add table public.products;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.banners;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
